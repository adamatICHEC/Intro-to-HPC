helloworld.cpp

#include <iostream>

using namespace std;
int main() 
{
cout << “Hello from C++” << endl;

return 0;
}
